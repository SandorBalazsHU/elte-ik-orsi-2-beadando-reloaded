#include "types.hpp"
#include <iostream>
#include <algorithm>
#include <iterator>
#include <cmath>
#include <future>


FIELD field_from_int(const int i)
{
    return FIELD::SEA;
}

int field_value(const FIELD& f)
{
    return 0;
}

int tile_value(const Tile& f)
{
    return 0;
}

bool operator<(const Coordinate& a, const Coordinate& b)
{
    return true;
}


std::ostream& operator<<(std::ostream& s, const FIELD& f)
{
    return s;
}

std::ostream& operator<<(std::ostream& s, const DIRECTION& d)
{
    return s;
}

std::ostream& operator<<(std::ostream& s, const Coordinate& p)
{
    return s;
}
std::istream& operator>>(std::istream& s, Coordinate& p)
{
    return s;
}

std::ostream& operator<<(std::ostream& s, const Tile& t)
{
    return s;
}

std::istream& operator>>(std::istream& s, Map& m)
{
    return s;
}

Map::Map()
{
    
}

Map::Map(const int r, const int c)
{
    
}
    
int Map::rows() const
{
    return 0;
}

int Map::cols() const
{
    return 0;
}

bool Map::in_range(const int x, const int y) const
{
    return false;
}

Tile Map::tile_at(const int i,const int j) const
{
    return std::make_pair(Coordinate(-1,-1), FIELD::SEA);
}

void Map::set_tile(const int i, const int j, const FIELD f)
{
    
}

Tile Map::tile_in_direction(int x, int y, const DIRECTION d) const
{
    return tile_at(0,0);
}

std::set<Tile> Map::get_tiles_in_radius(const int i, const int j, const int r) const
{
    std::set<Tile> s;
    return s;
}

/**
  * new functions for 2nd assignment
  */

void Map::find_cities()
{
	
}

double Map::get_length(const FlightPath& p) const
{
	return 0.0;
}

double Map::get_distance(const City& a, const City& b) const
{
	return 0.0;
}

FlightPath Map::closest_brute_force(const std::vector<City>& cities) const
{
	return {{0,0}, {0,0}};	
}

FlightPath Map::find_shortest(const std::vector<City>& x_cities, const std::vector<City>& y_cities) const
{
	return brute_force(x_cities);
}

std::set<City> Map::get_cities() const
{
	std::set<City> c;
	return c;
}

FlightPath Map::get_shortest_flightpath() const
{	
	std::vector<City> v;
	return find_shortest(v, v);
}

